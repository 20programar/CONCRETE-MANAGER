// Initialize Firebase (ADD YOUR OWN DATA)
var config = {
  apiKey: "AIzaSyCFxakqc89rI-gBT95fh2PqpoFLIyl7dr0",
  authDomain: "concrete2.firebaseapp.com",
  databaseURL: "https://concrete2.firebaseio.com",
  projectId: "concrete2",
  storageBucket: "",
  messagingSenderId: "392982692022"
};
firebase.initializeApp(config);

// Reference messages collection
var messagesRef = firebase.database().ref('sampleResults');

// Listen for form submit
document.getElementById('laboratory').addEventListener('submit', submitForm);

// Submit form
function submitForm(e){
  e.preventDefault();

  // Get values
  var sample_ID = getInputVal('sample_ID');
  var form_Number = getInputVal('form_Number');
  var dateTest = getInputVal('dateTest');
  var age = getInputVal('age');
  var mpa = getInputVal('mpa');
  var more_Information = getInputVal('more_Information');

  // Save message
  saveMessage(sample_ID,form_Number,dateTest,age,mpa,more_Information);

  // Show alert
  document.querySelector('.alert').style.display = 'block';

  // Hide alert after 3 seconds
  setTimeout(function(){
    document.querySelector('.alert').style.display = 'none';
  },3000);

  // Clear form
  document.getElementById('lab_Section').reset();
}

// Function to get get form values
function getInputVal(id){
  return document.getElementById(id).value;
}

// Save message to firebase
function saveMessage(sample_ID,form_Number,dateTest,age,mpa,more_Information){
  var newMessageRef = messagesRef.push();
  newMessageRef.set({
    sample_ID:sample_ID,
    form_Number:form_Number,
    dateTest:dateTest,
    age:age,
    mpa:mpa,
    more_Information:more_Information
  });
  // LAB FORM
  
}