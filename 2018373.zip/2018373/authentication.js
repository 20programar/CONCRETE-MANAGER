var btnLogin = document.getElementById('btnLogin');
var inputEmail = document.getElementById('inputEmail');
var inputPassword = document.getElementById('inputPassword');
var user;
btnLogin.addEventListener('click', function users(){
    console.log(inputEmail.value);
    if (inputEmail.value=="labuser@labuser.com"){
    var user="lab";
    window.location.replace('laboratory.html');
    console.log("lab")
    }
    if(inputEmail.value=="siteuser@siteuser.com"){
    var user="site";
    window.location.replace('site.html');
    console.log("site")
    }
    if(inputEmail.value=="engineeruser@engineeruser.com"){
    var user="engineer";
    console.log("engenheiro")
   window.location.replace('engineer.html');
    console.log(inputEmail);
    }
})

btnLogin.addEventListener('click', function () {

    firebase.auth().signInWithEmailAndPassword(inputEmail.value, inputPassword.value).then(
      function (result) {
        alert("User connected");
        console.log("Success!");
        return(users);
        

    }).catch(function (error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        // ...

       alert(errorMessage);
        // console.log("Failure!")
    });

});