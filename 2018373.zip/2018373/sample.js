// Initialize Firebase (ADD YOUR OWN DATA)
var config = {
  apiKey: "AIzaSyCFxakqc89rI-gBT95fh2PqpoFLIyl7dr0",
  authDomain: "concrete2.firebaseapp.com",
  databaseURL: "https://concrete2.firebaseio.com",
  projectId: "concrete2",
  storageBucket: "",
  messagingSenderId: "392982692022"
};
firebase.initializeApp(config);

// Reference messages collection
var messagesRef = firebase.database().ref('messages_sample');

// Listen for form submit
document.getElementById('sample').addEventListener('submit', submitForm);

// Submit form
function submitForm(e){
  e.preventDefault();

  // Get values
  var lay_Place = getInputVal('lay_Place');
  var form_Numer = getInputVal('form_Number');
  var truck_Order = getInputVal('truck_Order');
  var truck_Volume = getInputVal('truck_Volume');
  var mix_Time = getInputVal('mix_Time');
  var lay_Start_time = getInputVal('lay_Start_time');
  var lay_End_time = getInputVal('lay_End_time');
  var sample_ID = getInputVal('sample_ID');
  var sample_Amount = getInputVal('sample_Amount');
  var more_Information = getInputVal('more_Information');

  // Save message
  saveMessage(lay_Place,form_Numer,truck_Order,truck_Volume,mix_Time,lay_Start_time,lay_End_time,sample_ID,sample_Amount,more_Information);

  // Show alert
  document.querySelector('.alert').style.display = 'block';

  // Hide alert after 3 seconds
  setTimeout(function(){
    document.querySelector('.alert').style.display = 'none';
  },3000);

  // Clear form
  document.getElementById('lab_Section').reset();
}

// Function to get get form values
function getInputVal(id){
  return document.getElementById(id).value;
}

// Save message to firebase
function saveMessage(lay_Place, form_Number, truck_Order, truck_Volume,mix_Time, lay_Start_time,lay_End_time,sample_ID,sample_Amount,more_Information){
  var newMessageRef = messagesRef.push();
  newMessageRef.set({
    lay_Place:lay_Place,
    form_Number:form_Number,
    truck_Order:truck_Order,
    mix_Time:mix_Time,
    lay_Start_time:lay_Start_time,
    lay_End_time:(lay_End_time),
    sample_ID:sample_ID,
    sample_Amount:sample_Amount,
    more_Information:more_Information,
    truck_Volume:truck_Volume
  });
  // LAB FORM
  
}