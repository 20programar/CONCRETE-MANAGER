// Initialize Firebase (ADD YOUR OWN DATA)
var config = {
  apiKey: "AIzaSyCFxakqc89rI-gBT95fh2PqpoFLIyl7dr0",
  authDomain: "concrete2.firebaseapp.com",
  databaseURL: "https://concrete2.firebaseio.com",
  projectId: "concrete2",
  storageBucket: "",
  messagingSenderId: "392982692022"
};
firebase.initializeApp(config);
database = firebase.database();

var ref = database.ref('messages'); // scores
var ref2 = database.ref('messages_sample');
ref.on('value',gotData, errData);
ref.on('value',gotData2, errData2);

function gotData(data){
  //console.log(data.val());
  var messages = data.val();
  var keys = Object.keys(messages);
  console.log(keys);
  for (var i = 0; i < keys.length; i++){
    var k = keys[i];
    var builder_Name = messages[k].builder_Name; // builder_Name = initials
    var date_lab = messages[k].date_lab; // date_lab = initials
    var form_Number = messages[k].form_Number;
    var lay_Place = messages[k].lay_Place;
    var line_number = messages[k].line_number;
    var message = messages[k].message; 
    var site_Name = messages[k].site_Name;
    var volume_Project = messages[k].volume_Project;
    console.log("esse",message);
    //console.log("Builder name",builder_Name,"DATE LAB",date_lab);
    document.getElementById('date').innerHTML = "Date "+date_lab;
    document.getElementById('data').innerHTML = "Builder Name: "+builder_Name;
    document.getElementById('form_Number').innerHTML = "Form Number: "+form_Number;
    document.getElementById('lay_Place').innerHTML = "Lay place: "+lay_Place;
    document.getElementById('line_number').innerHTML = "Line_number: "+line_number;
    document.getElementById('message').innerHTML = "Message: "+message;
    document.getElementById('site_Name').innerHTML = "site_Name: "+site_Name;
    document.getElementById('volume_Project').innerHTML = "Project Volume (m3): "+volume_Project;

  }
}
//data2 *****************8
function gotData2(data){
  //console.log(data.val());
  var messages_sample = data.val();
  var keys = Object.keys(messages_sample);
  for (var i = 0; i < keys.length; i++){
    var k = keys[i];
    var form_Number = messages_sample[k].form_Number; 
    var lay_End_time = messages_sample[k].lay_End_time; 
    var lay_Place = messages_sample[k].lay_Place;
    var lay_Start_time = messages_sample[k].lay_Start_time;
    var mix_Time=mix_Time[k].mix_Time;
    var more_Information = more_Information[k].more_Information;
    var sample_Amount = sample_Amount[k].sample_Amount;
    var sample_ID = sample_ID[k].sample_ID;
    var truck_Order = truck_Order[k].truck_Order;
    var truck_Volume = truck_Volume[k].truck_Volume;
    console.log("esse2",form_Number,lay_End_time,lay_Place);  

    document.getElementById('lay_End_time').innerHTML = "Lay finish time "+lay_End_time;
    document.getElementById('lay_Place').innerHTML = "Lay place: "+lay_Place;
    document.getElementById('lay_Start_time').innerHTML = "Lay Start time: "+ lay_Start_time;
    document.getElementById('mix_Time').innerHTML = "Mix time: "+mix_Time;
    document.getElementById('more_Information').innerHTML = "More information; "+ more_Information;
    document.getElementById('sample_Amount').innerHTML = "Sample amount: " + sample_Amount;
    document.getElementById('sample_ID').innerHTML = "sample_ID" + sample_ID;
    document.getElementById('truck_Order').innerHTML = "Truck order: " + truck_Order;
    document.getElementById('truck_Volume'.innerHTML) = "truck_Volume: " + truck_Volume;
    //document.getElementById('data').innerHTML = "Builder Name: "+builder_Name;
   //document.getElementById('form_Number').innerHTML = "Form Number: "+form_Number;
   // document.getElementById('lay_Place').innerHTML = "Lay place: "+lay_Place;
   // document.getElementById('line_number').innerHTML = "Line_number: "+line_number;
    //document.getElementById('message').innerHTML = "Message: "+message;
    //document.getElementById('site_Name').innerHTML = "site_Name: "+site_Name;
    //document.getElementById('volume_Project').innerHTML = "Project Volume (m3): "+volume_Project;

 }
}

function errData(err) {
  console.log('Error!');
  console.log(err);
}
function errData2(err) {
  console.log('Error!');
  console.log(err);
}

// Reference messages collection
var messagesRef = firebase.database().ref('messages');

// Listen for form submit
document.getElementById('lab_Section').addEventListener('submit', submitForm);

// Submit form
function submitForm(e){
  e.preventDefault();

  // Get values
  var form_Number = getInputVal('form_Number');
  var date_Lab = getInputVal('date_Lab');
  var builder_Name = getInputVal('builder_Name');
  var site_Name = getInputVal('site_Name');
  var message = getInputVal('message');
  var line_Number = getInputVal('line_Number');
  var volume_Project = getInputVal('volume_Project');
  var lay_Place = getInputVal('lay_Place');

  // Save message
  saveMessage(form_Number, date_Lab, builder_Name, site_Name,line_Number, message,volume_Project,lay_Place);

  // Show alert
  document.querySelector('.alert').style.display = 'block';

  // Hide alert after 3 seconds
  setTimeout(function(){
    document.querySelector('.alert').style.display = 'none';
  },3000);

  // Clear form
  document.getElementById('lab_Section').reset();
}

// Function to get get form values
function getInputVal(id){
  return document.getElementById(id).value;
}

// Save message to firebase
function saveMessage(form_Number, date_lab, builder_Name, site_Name,line_number, message,volume_Project){
  var newMessageRef = messagesRef.push();
  newMessageRef.set({
    form_Number: form_Number,
    date_lab:date_lab,
    site_Name:site_Name,
    message:message,
    builder_Name:builder_Name,
    line_number:line_number,
    volume_Project:volume_Project,
    lay_Place:lay_Place
  });
  // LAB FORM
  
}